"""
Main Module - Customer Segmentation Project
Orchestrates the complete customer segmentation pipeline
"""

import os
import sys
import pandas as pd
import numpy as np
from pathlib import Path

# Add src directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from data_preprocessing import preprocess_pipeline
from clustering import elbow_method, train_kmeans, assign_clusters, get_cluster_statistics
from pca_analysis import perform_pca, get_pca_loadings
from visualization import (create_output_directory, plot_elbow_method, 
                          plot_customer_clusters, plot_pca_clusters, 
                          plot_cluster_distribution, generate_cluster_report_csv)


def create_sample_dataset(filepath, num_customers=200):
    """
    Create a sample Mall_Customers dataset if it doesn't exist
    
    Args:
        filepath (str): Path to save the dataset
        num_customers (int): Number of customer records to generate
    """
    print("\n⚠ Dataset not found. Creating sample dataset...")
    
    np.random.seed(42)
    
    data = {
        'CustomerID': range(1, num_customers + 1),
        'Gender': np.random.choice(['Male', 'Female'], num_customers),
        'Age': np.random.randint(18, 70, num_customers),
        'Annual Income (k$)': np.random.randint(15, 137, num_customers),
        'Spending Score (1-100)': np.random.randint(1, 101, num_customers)
    }
    
    df = pd.DataFrame(data)
    
    # Ensure directory exists
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    
    df.to_csv(filepath, index=False)
    print(f"✓ Sample dataset created: {filepath}")
    print(f"  Records: {len(df)}")
    print(f"  Columns: {list(df.columns)}")
    
    return df


def validate_dataset(filepath):
    """
    Validate and ensure dataset exists
    
    Args:
        filepath (str): Path to the dataset
        
    Returns:
        bool: True if dataset exists or was created
    """
    if not os.path.exists(filepath):
        create_sample_dataset(filepath)
    
    return True


def main():
    """
    Main execution pipeline for customer segmentation
    """
    print("\n" + "="*60)
    print("CUSTOMER SEGMENTATION USING K-MEANS CLUSTERING")
    print("="*60)
    
    # Setup paths
    project_root = os.path.dirname(os.path.abspath(__file__))
    dataset_path = os.path.join(project_root, 'dataset')
    
    # Try different possible filenames
    possible_filenames = ['Mall_Customers.csv', 'mall_customer.csv', 'mall_customers.csv']
    dataset_file = None
    
    for filename in possible_filenames:
        filepath = os.path.join(dataset_path, filename)
        if os.path.exists(filepath):
            dataset_file = filepath
            break
    
    # If not found, use the standard name and create if needed
    if dataset_file is None:
        dataset_file = os.path.join(dataset_path, 'Mall_Customers.csv')
        validate_dataset(dataset_file)
    
    # Create output directory
    output_path = os.path.join(project_root, 'outputs')
    create_output_directory(output_path)
    
    print("\n" + "="*60)
    print("PIPELINE EXECUTION")
    print("="*60)
    
    try:
        # Step 1: Data Preprocessing
        scaled_data, scaler, df_original, features = preprocess_pipeline(dataset_file)
        
        # Step 2: Elbow Method
        elbow_data = elbow_method(scaled_data, k_range=range(2, 11))
        plot_elbow_method(elbow_data, output_path)
        
        # Step 3: Determine optimal K (can be adjusted based on elbow curve)
        optimal_k = 3  # You can modify this based on elbow method results
        print(f"\n✓ Selected optimal K = {optimal_k}")
        
        # Step 4: Train K-Means
        kmeans_model = train_kmeans(scaled_data, optimal_k=optimal_k)
        
        # Step 5: Assign Clusters
        cluster_labels = assign_clusters(scaled_data, kmeans_model)
        
        # Step 6: Plot Customer Clusters
        plot_customer_clusters(scaled_data, cluster_labels, output_path)
        
        # Step 7: PCA Analysis
        pca_data, pca_model, explained_var = perform_pca(scaled_data, n_components=2)
        get_pca_loadings(pca_model, features)
        
        # Step 8: Plot PCA Clusters
        plot_pca_clusters(pca_data, cluster_labels, output_path)
        
        # Step 9: Get Cluster Statistics
        stats, df_with_clusters = get_cluster_statistics(df_original, features, cluster_labels)
        
        # Step 10: Plot Cluster Distribution
        plot_cluster_distribution(df_with_clusters, output_path)
        
        # Step 11: Generate Cluster Report
        report_df = generate_cluster_report_csv(stats, df_with_clusters, output_path)
        
        # Final Summary
        print("\n" + "="*60)
        print("EXECUTION COMPLETED SUCCESSFULLY")
        print("="*60)
        print(f"\n✓ All visualizations saved to: {output_path}")
        print(f"✓ Cluster report saved to: {os.path.join(output_path, 'cluster_report.csv')}")
        print(f"\nGenerated files:")
        print(f"  • elbow_method.png")
        print(f"  • customer_clusters.png")
        print(f"  • pca_clusters.png")
        print(f"  • cluster_distribution.png")
        print(f"  • cluster_report.csv")
        print(f"\n✓ Project completed successfully!")
        
        return 0
        
    except Exception as e:
        print(f"\n✗ Error during execution: {str(e)}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)
