@echo off
REM Customer Segmentation Project - Automated Setup Script
REM This script installs Python and runs the segmentation project

setlocal enabledelayedexpansion

echo.
echo ============================================================
echo CUSTOMER SEGMENTATION PROJECT - SETUP and EXECUTION
echo ============================================================
echo.

REM Step 1: Check if Python is installed
echo [1/4] Checking for Python installation...
python --version >nul 2>&1
if %errorlevel% equ 0 (
    echo Python is already installed.
    for /f "tokens=*" %%i in ('python --version') do set PYTHON_VERSION=%%i
    echo Found: !PYTHON_VERSION!
    goto :RUN_PROJECT
)

echo Python not found. Installing Python 3.11...

REM Step 2: Download Python installer
echo [2/4] Downloading Python 3.11.9 installer...
set INSTALLER=%TEMP%\python-installer.exe

powershell -Command "& {$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe' -OutFile '%INSTALLER%'}"

if not exist "%INSTALLER%" (
    echo ERROR: Failed to download Python installer
    echo Please download manually from: https://www.python.org/downloads/
    pause
    exit /b 1
)

echo Python installer downloaded successfully.

REM Step 3: Install Python
echo [3/4] Installing Python 3.11.9...
"%INSTALLER%" /quiet InstallAllUsers=1 PrependPath=1
if %errorlevel% neq 0 (
    echo Warning: Installation returned code %errorlevel%
)

timeout /t 5 /nobreak
del "%INSTALLER%"

REM Refresh environment variables
set PATH=%PATH%;C:\Program Files\Python311;C:\Program Files\Python311\Scripts

REM Verify Python installation
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Python installation verification failed
    echo Please install Python manually from: https://www.python.org/downloads/
    pause
    exit /b 1
)

:RUN_PROJECT

REM Step 4: Install dependencies and run project
echo [4/4] Installing dependencies and running project...
echo.

cd /d "%~dp0"

REM Install requirements
echo Installing Python packages...
python -m pip install --upgrade pip --quiet
python -m pip install -r requirements.txt --quiet

if %errorlevel% neq 0 (
    echo ERROR: Failed to install dependencies
    echo Please run manually: pip install -r requirements.txt
    pause
    exit /b 1
)

echo.
echo ============================================================
echo EXECUTING CUSTOMER SEGMENTATION PROJECT
echo ============================================================
echo.

REM Run the main project
python main.py

if %errorlevel% equ 0 (
    echo.
    echo ============================================================
    echo PROJECT EXECUTED SUCCESSFULLY
    echo ============================================================
    echo Check the 'outputs' folder for generated files:
    echo   - elbow_method.png
    echo   - customer_clusters.png
    echo   - pca_clusters.png
    echo   - cluster_distribution.png
    echo   - cluster_report.csv
    echo.
) else (
    echo.
    echo ERROR: Project execution failed with code %errorlevel%
    echo.
)

pause
exit /b %errorlevel%
