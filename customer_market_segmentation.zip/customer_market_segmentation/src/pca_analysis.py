"""
PCA Analysis Module
Handles Principal Component Analysis for dimensionality reduction
"""

import numpy as np
from sklearn.decomposition import PCA
import warnings
warnings.filterwarnings('ignore')


def perform_pca(scaled_data, n_components=2):
    """
    Perform PCA to reduce dimensions
    
    Args:
        scaled_data (np.ndarray): Standardized feature data
        n_components (int): Number of principal components (default: 2)
        
    Returns:
        tuple: (pca_data, pca_model, explained_variance_ratio)
    """
    print("\n" + "="*60)
    print(f"PRINCIPAL COMPONENT ANALYSIS")
    print("="*60)
    
    pca = PCA(n_components=n_components)
    pca_data = pca.fit_transform(scaled_data)
    
    explained_var_ratio = pca.explained_variance_ratio_
    cumulative_var_ratio = np.cumsum(explained_var_ratio)
    
    print(f"✓ PCA performed with {n_components} components")
    print(f"\nExplained Variance Ratio:")
    for i, var in enumerate(explained_var_ratio):
        print(f"  PC{i+1}: {var:.4f} ({var*100:.2f}%)")
    
    print(f"\nCumulative Explained Variance:")
    for i, cum_var in enumerate(cumulative_var_ratio):
        print(f"  PC1-PC{i+1}: {cum_var:.4f} ({cum_var*100:.2f}%)")
    
    total_explained = cumulative_var_ratio[-1]
    print(f"\n✓ Total Variance Explained: {total_explained*100:.2f}%")
    
    return pca_data, pca, explained_var_ratio


def get_pca_components(pca_model):
    """
    Get PCA component details
    
    Args:
        pca_model (PCA): Fitted PCA model
        
    Returns:
        np.ndarray: PCA components
    """
    components = pca_model.components_
    return components


def get_pca_loadings(pca_model, feature_names):
    """
    Get PCA loadings for feature interpretation
    
    Args:
        pca_model (PCA): Fitted PCA model
        feature_names (list): List of original feature names
        
    Returns:
        dict: Dictionary mapping features to their loadings
    """
    loadings = {}
    
    for i, feature in enumerate(feature_names):
        loadings[feature] = pca_model.components_[:, i]
    
    print("\n" + "="*60)
    print("PCA LOADINGS (Feature Contributions)")
    print("="*60)
    
    for i, feature in enumerate(feature_names):
        print(f"\n{feature}:")
        for pc in range(len(pca_model.components_)):
            loading = pca_model.components_[pc, i]
            print(f"  PC{pc+1}: {loading:7.4f}")
    
    return loadings
