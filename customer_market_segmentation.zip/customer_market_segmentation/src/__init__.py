# src module for customer segmentation project
