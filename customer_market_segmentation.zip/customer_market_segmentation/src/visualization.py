"""
Visualization Module
Handles creating plots for clustering analysis and PCA visualization
"""

import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import os
import warnings
warnings.filterwarnings('ignore')

# Set style
sns.set_style("darkgrid")
plt.rcParams['figure.figsize'] = (12, 8)


def create_output_directory(output_path="outputs"):
    """
    Create output directory if it doesn't exist
    
    Args:
        output_path (str): Path to output directory
    """
    if not os.path.exists(output_path):
        os.makedirs(output_path)
        print(f"✓ Created output directory: {output_path}")
    else:
        print(f"✓ Output directory exists: {output_path}")


def plot_elbow_method(elbow_data, output_path="outputs"):
    """
    Plot elbow method graph
    
    Args:
        elbow_data (dict): Dictionary with k_values and inertias
        output_path (str): Path to save the plot
    """
    print("\n" + "="*60)
    print("GENERATING ELBOW METHOD VISUALIZATION")
    print("="*60)
    
    plt.figure(figsize=(10, 6))
    
    k_values = elbow_data['k_values']
    inertias = elbow_data['inertias']
    
    plt.plot(k_values, inertias, 'bo-', linewidth=2, markersize=8)
    plt.xlabel('Number of Clusters (K)', fontsize=12, fontweight='bold')
    plt.ylabel('Inertia', fontsize=12, fontweight='bold')
    plt.title('Elbow Method for Optimal K', fontsize=14, fontweight='bold')
    plt.grid(True, alpha=0.3)
    plt.xticks(k_values)
    
    # Add annotations
    for i, (k, inertia) in enumerate(zip(k_values, inertias)):
        plt.annotate(f'{inertia:.0f}', xy=(k, inertia), xytext=(0, 10),
                    textcoords='offset points', ha='center', fontsize=9)
    
    plt.tight_layout()
    filepath = os.path.join(output_path, 'elbow_method.png')
    plt.savefig(filepath, dpi=300, bbox_inches='tight')
    print(f"✓ Saved: {filepath}")
    plt.close()


def plot_customer_clusters(scaled_data, cluster_labels, output_path="outputs"):
    """
    Plot customer clusters (first two features)
    
    Args:
        scaled_data (np.ndarray): Standardized feature data
        cluster_labels (np.ndarray): Cluster labels
        output_path (str): Path to save the plot
    """
    print("\n" + "="*60)
    print("GENERATING CUSTOMER CLUSTERS VISUALIZATION")
    print("="*60)
    
    plt.figure(figsize=(12, 8))
    
    # Get unique clusters
    unique_clusters = np.unique(cluster_labels)
    colors = sns.color_palette("husl", len(unique_clusters))
    
    # Plot clusters
    for cluster, color in zip(unique_clusters, colors):
        mask = cluster_labels == cluster
        plt.scatter(scaled_data[mask, 0], scaled_data[mask, 1],
                   label=f'Cluster {cluster}', s=100, alpha=0.7,
                   color=color, edgecolors='black', linewidth=0.5)
    
    plt.xlabel('Feature 1 (Standardized)', fontsize=12, fontweight='bold')
    plt.ylabel('Feature 2 (Standardized)', fontsize=12, fontweight='bold')
    plt.title('Customer Clusters (K-Means)', fontsize=14, fontweight='bold')
    plt.legend(loc='best', fontsize=11)
    plt.grid(True, alpha=0.3)
    
    plt.tight_layout()
    filepath = os.path.join(output_path, 'customer_clusters.png')
    plt.savefig(filepath, dpi=300, bbox_inches='tight')
    print(f"✓ Saved: {filepath}")
    plt.close()


def plot_pca_clusters(pca_data, cluster_labels, output_path="outputs"):
    """
    Plot PCA-reduced clusters in 2D
    
    Args:
        pca_data (np.ndarray): PCA-transformed data
        cluster_labels (np.ndarray): Cluster labels
        output_path (str): Path to save the plot
    """
    print("\n" + "="*60)
    print("GENERATING PCA CLUSTERS VISUALIZATION")
    print("="*60)
    
    plt.figure(figsize=(12, 8))
    
    # Get unique clusters
    unique_clusters = np.unique(cluster_labels)
    colors = sns.color_palette("husl", len(unique_clusters))
    
    # Plot clusters
    for cluster, color in zip(unique_clusters, colors):
        mask = cluster_labels == cluster
        plt.scatter(pca_data[mask, 0], pca_data[mask, 1],
                   label=f'Cluster {cluster}', s=100, alpha=0.7,
                   color=color, edgecolors='black', linewidth=0.5)
    
    plt.xlabel('First Principal Component', fontsize=12, fontweight='bold')
    plt.ylabel('Second Principal Component', fontsize=12, fontweight='bold')
    plt.title('Customer Clusters (PCA Visualization)', fontsize=14, fontweight='bold')
    plt.legend(loc='best', fontsize=11)
    plt.grid(True, alpha=0.3)
    
    plt.tight_layout()
    filepath = os.path.join(output_path, 'pca_clusters.png')
    plt.savefig(filepath, dpi=300, bbox_inches='tight')
    print(f"✓ Saved: {filepath}")
    plt.close()


def plot_cluster_distribution(df_with_clusters, output_path="outputs"):
    """
    Plot distribution of customers across clusters
    
    Args:
        df_with_clusters (pd.DataFrame): Dataframe with cluster labels
        output_path (str): Path to save the plot
    """
    print("\n" + "="*60)
    print("GENERATING CLUSTER DISTRIBUTION VISUALIZATION")
    print("="*60)
    
    plt.figure(figsize=(10, 6))
    
    cluster_counts = df_with_clusters['Cluster'].value_counts().sort_index()
    colors = sns.color_palette("husl", len(cluster_counts))
    
    bars = plt.bar(cluster_counts.index, cluster_counts.values, color=colors, 
                   edgecolor='black', linewidth=1.5)
    
    # Add value labels on bars
    for bar in bars:
        height = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2., height,
                f'{int(height)}',
                ha='center', va='bottom', fontweight='bold', fontsize=11)
    
    plt.xlabel('Cluster', fontsize=12, fontweight='bold')
    plt.ylabel('Number of Customers', fontsize=12, fontweight='bold')
    plt.title('Distribution of Customers Across Clusters', fontsize=14, fontweight='bold')
    plt.xticks(cluster_counts.index)
    plt.grid(True, alpha=0.3, axis='y')
    
    plt.tight_layout()
    filepath = os.path.join(output_path, 'cluster_distribution.png')
    plt.savefig(filepath, dpi=300, bbox_inches='tight')
    print(f"✓ Saved: {filepath}")
    plt.close()


def generate_cluster_report_csv(stats, df_with_clusters, output_path="outputs"):
    """
    Generate and save cluster report as CSV
    
    Args:
        stats (list): List of cluster statistics
        df_with_clusters (pd.DataFrame): Dataframe with cluster labels
        output_path (str): Path to save the report
    """
    print("\n" + "="*60)
    print("GENERATING CLUSTER REPORT")
    print("="*60)
    
    import pandas as pd
    
    # Create dataframe from stats
    report_df = pd.DataFrame(stats)
    
    # Save to CSV
    filepath = os.path.join(output_path, 'cluster_report.csv')
    report_df.to_csv(filepath, index=False)
    
    print(f"✓ Cluster Report saved: {filepath}")
    print("\nCluster Report Summary:")
    print(report_df.to_string(index=False))
    
    return report_df
