"""
K-Means Clustering Module
Handles elbow method, K-Means model training, and cluster assignment
"""

import numpy as np
from sklearn.cluster import KMeans
import warnings
warnings.filterwarnings('ignore')


def elbow_method(scaled_data, k_range=range(2, 11)):
    """
    Perform elbow method to find optimal number of clusters
    
    Args:
        scaled_data (np.ndarray): Standardized feature data
        k_range (range): Range of K values to test (default: 2-10)
        
    Returns:
        dict: Dictionary with k values and inertia values
    """
    inertias = []
    silhouette_scores = []
    
    print("\n" + "="*60)
    print("ELBOW METHOD - FINDING OPTIMAL K")
    print("="*60)
    
    for k in k_range:
        kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
        kmeans.fit(scaled_data)
        inertias.append(kmeans.inertia_)
        print(f"K={k}: Inertia={kmeans.inertia_:.2f}")
    
    elbow_data = {
        'k_values': list(k_range),
        'inertias': inertias
    }
    
    print("✓ Elbow method completed")
    
    return elbow_data


def train_kmeans(scaled_data, optimal_k=3):
    """
    Train K-Means model with optimal number of clusters
    
    Args:
        scaled_data (np.ndarray): Standardized feature data
        optimal_k (int): Optimal number of clusters (default: 3)
        
    Returns:
        KMeans: Trained K-Means model
    """
    print("\n" + "="*60)
    print(f"TRAINING K-MEANS MODEL (K={optimal_k})")
    print("="*60)
    
    kmeans = KMeans(n_clusters=optimal_k, random_state=42, n_init=10)
    kmeans.fit(scaled_data)
    
    print(f"✓ K-Means model trained successfully")
    print(f"  Inertia: {kmeans.inertia_:.2f}")
    print(f"  Number of clusters: {len(np.unique(kmeans.labels_))}")
    
    return kmeans


def assign_clusters(scaled_data, kmeans_model):
    """
    Assign cluster labels to data points
    
    Args:
        scaled_data (np.ndarray): Standardized feature data
        kmeans_model (KMeans): Trained K-Means model
        
    Returns:
        np.ndarray: Cluster labels for each data point
    """
    cluster_labels = kmeans_model.predict(scaled_data)
    
    print(f"✓ Cluster labels assigned to {len(cluster_labels)} data points")
    
    return cluster_labels


def get_cluster_statistics(original_df, feature_cols, cluster_labels):
    """
    Calculate statistics for each cluster
    
    Args:
        original_df (pd.DataFrame): Original dataframe with all columns
        feature_cols (list): List of feature column names used in clustering
        cluster_labels (np.ndarray): Cluster labels for each data point
        
    Returns:
        dict: Cluster statistics
    """
    print("\n" + "="*60)
    print("CLUSTER STATISTICS")
    print("="*60)
    
    # Add cluster labels to dataframe
    df_with_clusters = original_df.copy()
    df_with_clusters['Cluster'] = cluster_labels
    
    stats = []
    
    for cluster in sorted(np.unique(cluster_labels)):
        cluster_data = df_with_clusters[df_with_clusters['Cluster'] == cluster]
        
        stat_dict = {
            'Cluster': cluster,
            'Customer_Count': len(cluster_data),
            'Avg_Age': cluster_data[['Age']].mean().values[0] if 'Age' in cluster_data.columns else None,
            'Avg_Income': cluster_data[['Annual Income (k$)']].mean().values[0] if 'Annual Income (k$)' in cluster_data.columns else None,
            'Avg_Spending_Score': cluster_data[['Spending Score (1-100)']].mean().values[0] if 'Spending Score (1-100)' in cluster_data.columns else None
        }
        
        stats.append(stat_dict)
        
        print(f"\nCluster {cluster}:")
        print(f"  Customers: {stat_dict['Customer_Count']}")
        if stat_dict['Avg_Age'] is not None:
            print(f"  Avg Age: {stat_dict['Avg_Age']:.2f} years")
        if stat_dict['Avg_Income'] is not None:
            print(f"  Avg Income: ${stat_dict['Avg_Income']:.2f}k")
        if stat_dict['Avg_Spending_Score'] is not None:
            print(f"  Avg Spending Score: {stat_dict['Avg_Spending_Score']:.2f}")
    
    return stats, df_with_clusters
