"""
Data Preprocessing Module
Handles data loading, cleaning, and standardization for customer segmentation
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')


def load_data(filepath):
    """
    Load customer data from CSV file
    
    Args:
        filepath (str): Path to the CSV file
        
    Returns:
        pd.DataFrame: Loaded dataframe
    """
    try:
        df = pd.read_csv(filepath)
        print(f"✓ Data loaded successfully: {df.shape[0]} records, {df.shape[1]} columns")
        return df
    except FileNotFoundError:
        print(f"✗ Error: File '{filepath}' not found")
        raise
    except Exception as e:
        print(f"✗ Error loading data: {str(e)}")
        raise


def handle_missing_values(df):
    """
    Handle missing values in the dataset
    
    Args:
        df (pd.DataFrame): Input dataframe
        
    Returns:
        pd.DataFrame: Dataframe with missing values handled
    """
    initial_missing = df.isnull().sum().sum()
    
    if initial_missing > 0:
        print(f"⚠ Found {initial_missing} missing values")
        # Drop rows with missing values
        df = df.dropna()
        print(f"✓ Missing values handled (rows removed: {initial_missing})")
    else:
        print("✓ No missing values found")
    
    return df


def select_features(df):
    """
    Select relevant features for clustering
    Excludes ID and Customer_ID columns
    
    Args:
        df (pd.DataFrame): Input dataframe
        
    Returns:
        pd.DataFrame: Dataframe with selected features
        list: List of selected feature names
    """
    # Columns to exclude
    exclude_cols = ['CustomerID', 'Customer_ID', 'ID']
    
    # Get numerical columns
    numerical_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    
    # Remove ID columns
    features = [col for col in numerical_cols if col not in exclude_cols]
    
    print(f"✓ Selected features: {features}")
    return df[features], features


def standardize_data(df):
    """
    Standardize features using StandardScaler
    
    Args:
        df (pd.DataFrame): Input dataframe with features
        
    Returns:
        np.ndarray: Standardized data
        StandardScaler: Fitted scaler object
    """
    scaler = StandardScaler()
    scaled_data = scaler.fit_transform(df)
    
    print(f"✓ Data standardized using StandardScaler")
    print(f"  Mean: {scaled_data.mean():.4f}, Std: {scaled_data.std():.4f}")
    
    return scaled_data, scaler


def preprocess_pipeline(filepath):
    """
    Complete preprocessing pipeline
    
    Args:
        filepath (str): Path to the dataset
        
    Returns:
        tuple: (scaled_data, scaler, original_df, features)
    """
    print("\n" + "="*60)
    print("DATA PREPROCESSING PIPELINE")
    print("="*60)
    
    # Load data
    df = load_data(filepath)
    
    # Display basic info
    print(f"\nDataset shape: {df.shape}")
    print(f"Columns: {list(df.columns)}")
    
    # Handle missing values
    df = handle_missing_values(df)
    
    # Select features
    features_df, features = select_features(df)
    
    # Standardize data
    scaled_data, scaler = standardize_data(features_df)
    
    print("\n✓ Preprocessing completed successfully!")
    
    return scaled_data, scaler, df, features
