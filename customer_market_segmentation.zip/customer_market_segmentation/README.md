# Customer Segmentation using K-Means Clustering

## Project Overview

This is a comprehensive machine learning project that performs customer segmentation analysis using K-Means clustering. The project implements a complete pipeline for data preprocessing, clustering analysis, principal component analysis (PCA), and visualization of customer segments.

### Key Features

- **Data Preprocessing**: Handles missing values, feature selection, and data standardization
- **Elbow Method**: Automatically determines the optimal number of clusters
- **K-Means Clustering**: Segments customers into distinct groups
- **PCA Analysis**: Reduces dimensions to 2 principal components for visualization
- **Comprehensive Visualizations**: Generates multiple plots for analysis
- **Cluster Statistics**: Provides detailed metrics for each customer segment
- **Modular Architecture**: Well-organized code with separate modules for each functionality

## Project Structure

```
customer_market_segmentation/
├── dataset/
│   └── Mall_Customers.csv
├── outputs/
│   ├── elbow_method.png
│   ├── customer_clusters.png
│   ├── pca_clusters.png
│   ├── cluster_distribution.png
│   └── cluster_report.csv
├── src/
│   ├── data_preprocessing.py
│   ├── clustering.py
│   ├── pca_analysis.py
│   ├── visualization.py
│   └── __init__.py
├── main.py
├── requirements.txt
├── README.md
└── .gitignore
```

## Installation

### Prerequisites

- Python 3.7 or higher
- pip (Python package manager)

### Setup Steps

1. **Clone or download the project**
   ```bash
   cd customer_market_segmentation
   ```

2. **Create a virtual environment (recommended)**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

## Execution

### Running the Project

Execute the main script to run the complete pipeline:

```bash
python main.py
```

### What Happens During Execution

1. **Data Loading**: Loads customer data from `dataset/Mall_Customers.csv`
   - If the file doesn't exist, a sample dataset is automatically generated
   
2. **Data Preprocessing**: 
   - Checks for and handles missing values
   - Selects numerical features
   - Standardizes features using StandardScaler

3. **Elbow Method Analysis**:
   - Tests K values from 2 to 10
   - Calculates inertia for each K
   - Generates elbow curve visualization

4. **K-Means Clustering**:
   - Trains K-Means model with optimal K (default: 3)
   - Assigns cluster labels to customers

5. **PCA Analysis**:
   - Reduces data to 2 principal components
   - Calculates explained variance ratio
   - Generates PCA loadings

6. **Visualizations**:
   - Elbow method curve
   - Customer clusters scatter plot
   - PCA-based cluster visualization
   - Cluster distribution bar chart

7. **Report Generation**:
   - Creates cluster statistics CSV file
   - Shows summary statistics per cluster

## Dependencies

The project uses the following Python libraries:

- **pandas** (2.0.3): Data manipulation and analysis
- **numpy** (1.24.3): Numerical computing
- **matplotlib** (3.7.2): Data visualization
- **seaborn** (0.12.2): Statistical data visualization
- **scikit-learn** (1.3.0): Machine learning library
- **scipy** (1.11.2): Scientific computing

All dependencies are listed in `requirements.txt` and can be installed with a single command.

## Usage Examples

### Basic Execution

```bash
python main.py
```

This runs the complete pipeline with default parameters.

### Sample Output

When executed successfully, the program produces:

**Console Output:**
```
============================================================
CUSTOMER SEGMENTATION USING K-MEANS CLUSTERING
============================================================

============================================================
DATA PREPROCESSING PIPELINE
============================================================
✓ Data loaded successfully: 200 records, 5 columns
...
✓ Preprocessing completed successfully!

============================================================
ELBOW METHOD - FINDING OPTIMAL K
============================================================
K=2: Inertia=... 
K=3: Inertia=...
...

============================================================
CLUSTER STATISTICS
============================================================
Cluster 0:
  Customers: 50
  Avg Age: 35.2 years
  Avg Income: $65.3k
  Avg Spending Score: 75.5

...

✓ All visualizations saved to: outputs/
✓ Project completed successfully!
```

### Output Files

The project generates the following files in the `outputs/` directory:

1. **elbow_method.png**
   - Shows inertia vs number of clusters
   - Helps identify the optimal K value
   - Elbow point indicates best K

2. **customer_clusters.png**
   - Scatter plot of first two features
   - Points colored by cluster assignment
   - Shows cluster separation

3. **pca_clusters.png**
   - Scatter plot in PCA space
   - First two principal components
   - Shows variance-explained visualization

4. **cluster_distribution.png**
   - Bar chart showing customers per cluster
   - Helps analyze cluster size distribution

5. **cluster_report.csv**
   - Detailed statistics for each cluster
   - Includes:
     - Number of customers
     - Average age
     - Average annual income
     - Average spending score

## Features in Detail

### Data Preprocessing Module (`data_preprocessing.py`)

- **load_data()**: Loads CSV file and validates structure
- **handle_missing_values()**: Removes rows with missing data
- **select_features()**: Selects numerical features for clustering
- **standardize_data()**: Normalizes features using StandardScaler
- **preprocess_pipeline()**: Orchestrates complete preprocessing

### Clustering Module (`clustering.py`)

- **elbow_method()**: Performs elbow method analysis for K=2 to 10
- **train_kmeans()**: Trains K-Means model with specified K
- **assign_clusters()**: Assigns cluster labels to data points
- **get_cluster_statistics()**: Calculates per-cluster statistics

### PCA Module (`pca_analysis.py`)

- **perform_pca()**: Reduces dimensionality to specified components
- **get_pca_components()**: Returns principal component vectors
- **get_pca_loadings()**: Calculates feature contributions to components

### Visualization Module (`visualization.py`)

- **create_output_directory()**: Ensures output folder exists
- **plot_elbow_method()**: Generates elbow curve
- **plot_customer_clusters()**: Visualizes clusters in feature space
- **plot_pca_clusters()**: Visualizes clusters in PCA space
- **plot_cluster_distribution()**: Bar chart of cluster sizes
- **generate_cluster_report_csv()**: Creates cluster statistics report

## Customization

### Changing the Number of Clusters

Edit `main.py` and modify the `optimal_k` variable:

```python
optimal_k = 4  # Change from 3 to desired number
```

### Using Your Own Dataset

Replace `dataset/Mall_Customers.csv` with your dataset. Ensure it has columns:
- Age
- Annual Income (k$)
- Spending Score (1-100)

Or modify the feature selection in `data_preprocessing.py`.

### Adjusting PCA Components

In `main.py`, modify the PCA call:

```python
pca_data, pca_model, explained_var = perform_pca(scaled_data, n_components=3)
```

## Troubleshooting

### Issue: Dataset not found
**Solution**: The program automatically generates a sample dataset if none exists

### Issue: Module import errors
**Solution**: Ensure you're running from the project root directory and the virtual environment is activated

### Issue: Matplotlib display errors (in headless environments)
**Solution**: The code saves all plots to files; no display is required

## Performance Considerations

- Dataset with 200 records: ~2-5 seconds
- Dataset with 1000+ records: ~10-30 seconds
- Visualizations generation: ~5-15 seconds

## Algorithm Explanation

### K-Means Clustering
K-Means partitions data into K clusters by minimizing within-cluster variance. The algorithm:
1. Initializes K random centroids
2. Assigns points to nearest centroid
3. Updates centroids based on cluster mean
4. Repeats until convergence

### Elbow Method
Identifies optimal K by plotting inertia vs K and finding the "elbow" point where adding more clusters provides diminishing returns.

### PCA (Principal Component Analysis)
Reduces dimensionality while preserving variance. First two components capture maximum variance in reduced dimensions.

## Future Enhancements

- Interactive visualizations with Plotly
- Silhouette analysis for cluster quality
- Hierarchical clustering comparison
- Real-time parameter tuning
- Database integration for customer data
- Web interface for analysis

## License

This project is open source and available for educational and commercial use.

## Author

Machine Learning Project - Customer Segmentation

## Support

For issues or questions, please refer to the code documentation and comments throughout the modules.

---

**Created**: June 2024  
**Last Updated**: June 2024  
**Version**: 1.0.0
