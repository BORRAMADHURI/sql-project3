#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Customer Segmentation Project Setup and Execution Script
.DESCRIPTION
    Automatically installs Python, dependencies, and runs the segmentation project
.NOTES
    Run as Administrator: Right-click PowerShell and select "Run as Administrator"
#>

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "CUSTOMER SEGMENTATION PROJECT - SETUP & EXECUTION" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# Step 1: Check Python installation
Write-Host "[1/4] Checking for Python installation..." -ForegroundColor Yellow
$pythonCheck = $null
try {
    $pythonCheck = & python --version 2>&1
    Write-Host "✓ Python found: $pythonCheck" -ForegroundColor Green
} catch {
    Write-Host "⚠ Python not found. Attempting installation..." -ForegroundColor Yellow
    
    # Step 2: Download Python
    Write-Host "[2/4] Downloading Python 3.11.9..." -ForegroundColor Yellow
    $installerPath = "$env:TEMP\python-installer.exe"
    $pythonUrl = "https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe"
    
    try {
        $ProgressPreference = 'SilentlyContinue'
        Invoke-WebRequest -Uri $pythonUrl -OutFile $installerPath -ErrorAction Stop
        Write-Host "✓ Installer downloaded successfully" -ForegroundColor Green
    } catch {
        Write-Host "✗ ERROR: Failed to download Python installer" -ForegroundColor Red
        Write-Host "Please download manually from: https://www.python.org/downloads/" -ForegroundColor Yellow
        Read-Host "Press Enter to exit"
        exit 1
    }
    
    # Step 3: Install Python
    Write-Host "[3/4] Installing Python 3.11.9..." -ForegroundColor Yellow
    try {
        Start-Process -FilePath $installerPath -ArgumentList "/quiet InstallAllUsers=1 PrependPath=1" -Wait -NoNewWindow
        Write-Host "✓ Python installed successfully" -ForegroundColor Green
        Remove-Item -Path $installerPath -Force -ErrorAction SilentlyContinue
        
        # Refresh PATH
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")
        
        # Verify installation
        Start-Sleep -Seconds 3
        $pythonCheck = & python --version 2>&1
        Write-Host "✓ Verification: $pythonCheck" -ForegroundColor Green
    } catch {
        Write-Host "✗ ERROR: Python installation failed" -ForegroundColor Red
        Write-Host "Please install Python manually from: https://www.python.org/downloads/" -ForegroundColor Yellow
        Read-Host "Press Enter to exit"
        exit 1
    }
}

# Step 4: Run project
Write-Host ""
Write-Host "[4/4] Setting up environment and running project..." -ForegroundColor Yellow
Write-Host ""

$projectRoot = Split-Path -Parent -Path (Get-Location)
cd (Split-Path -Parent -Path $MyInvocation.MyCommand.Path)

# Install dependencies
Write-Host "Installing Python packages..." -ForegroundColor Cyan
try {
    python -m pip install --upgrade pip --quiet -ErrorAction Stop
    python -m pip install -r requirements.txt --quiet -ErrorAction Stop
    Write-Host "✓ Dependencies installed" -ForegroundColor Green
} catch {
    Write-Host "✗ ERROR: Failed to install dependencies" -ForegroundColor Red
    Write-Host "Run manually: pip install -r requirements.txt" -ForegroundColor Yellow
    Read-Host "Press Enter to exit"
    exit 1
}

# Run main project
Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "EXECUTING CUSTOMER SEGMENTATION PROJECT" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

python main.py
$exitCode = $LASTEXITCODE

if ($exitCode -eq 0) {
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Green
    Write-Host "✓ PROJECT EXECUTED SUCCESSFULLY" -ForegroundColor Green
    Write-Host "============================================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "Check the 'outputs' folder for generated files:" -ForegroundColor Cyan
    Write-Host "  • elbow_method.png" -ForegroundColor White
    Write-Host "  • customer_clusters.png" -ForegroundColor White
    Write-Host "  • pca_clusters.png" -ForegroundColor White
    Write-Host "  • cluster_distribution.png" -ForegroundColor White
    Write-Host "  • cluster_report.csv" -ForegroundColor White
    Write-Host ""
} else {
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Red
    Write-Host "✗ ERROR: Project execution failed with code $exitCode" -ForegroundColor Red
    Write-Host "============================================================" -ForegroundColor Red
    Write-Host ""
}

Read-Host "Press Enter to exit"
exit $exitCode
